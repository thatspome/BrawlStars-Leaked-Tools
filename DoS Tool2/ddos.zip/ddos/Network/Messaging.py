from Streams.PacketStream import PacketStream

class Messaging:
	def __init__(self):
		pass
	
	def sendMessage(self, type, sock, data):
		header = b""
		type = PacketStream.writeShort(type)
		#data = bytes.fromhex(data)
		dudka = PacketStream.writeShort(0)
		
		header = type + len(data).to_bytes(3, 'big') + dudka
		
		sock.send(header + data)
	
	def recvall(self, sock, msgLen):
		recvedData = b''
		while msgLen > 0:
			dudka = sock.recv(msgLen)
			if not dudka:
				print("cho")
				raise MemoryError
			recvedData += dudka
			msgLen -= len(dudka)
		return recvedData
	
	def recvData(self, sock):
		header = sock.recv(7)
		messageType = int.from_bytes(header[:2], 'big')
		messageLen = int.from_bytes(header[2:5], 'big')
		data = Messaging.recvall(self, sock, messageLen)
		if not data:
			return
		else:
			return data