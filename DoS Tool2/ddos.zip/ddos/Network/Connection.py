from Utilities.Debugger import Debugger
from Utilities.CommandsManager import CommandsManager

from Streams.ByteStream import ByteStream
from Streams.PacketStream import PacketStream

from Protocol.LogicLaserMessageFactory import LogicLaserMessageFactory

from Network.Messaging import Messaging

class Connection:
	def __init__(self):
		self.commandManager = CommandsManager()
	
	def connect(self, sock, ip, port):
		Debugger.log("Connecting to %s:%i..." % (ip, port))
		sock.connect((ip, port))
		Debugger.log("Connected!")
	
	def disconnect(self, sock):
		sock.close()
		Debugger.log("Disconnected!")
	
	def process(self, sock):
		print("Get all commands list: /help")
		
		while True:
			self.commandManager.cmd(sock)