import socket
import json

from Utilities.Debugger import Debugger

from Network.Connection import Connection

class bsClient:
	def __init__(self):
		print("""THIS TOOL MADE BY
  _                  _                _         _        
 | |           ____ | |              | |       | |       
 | |_ __ _    / __ \| |__  _ __ _   _| |__  ___| |_ __ _ 
 | __/ _` |  / / _` | '_ \| '__| | | | '_ \/ __| __/ _` |
 | || (_| | | | (_| | |_) | |  | |_| | | | \__ \ || (_| |
  \__\__, |  \ \__,_|_.__/|_|   \__,_|_| |_|___/\__\__,_|
      __/ |   \____/                                     
     |___/                                               
""")
		Debugger.log("Loading parameters...")
		self.s = socket.socket()
		self.config = json.loads(open("config.json", "r").read())
		
		self.ip = self.config["ip"]
		self.port = self.config["port"]
		
		Debugger.log("Loaded %i options" % len(self.config))
	
	def start(self):
		c = Connection()
		c.connect(self.s, self.ip, self.port)
		c.process(self.s)

if __name__ == "__main__":
	app = bsClient()
	app.start()