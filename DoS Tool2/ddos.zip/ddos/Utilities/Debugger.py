class Debugger:
	def log(text):
		print("[DEBUG] %s" % text)
	
	def warn(text):
		print("[WARNING] %s" % text)
	
	def err(text):
		print("[ERROR] %s" % text)