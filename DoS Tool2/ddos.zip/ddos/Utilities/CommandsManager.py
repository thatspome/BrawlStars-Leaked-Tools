from Utilities.Debugger import Debugger

from Network.Messaging import Messaging
from Protocol.LogicLaserMessageFactory import LogicLaserMessageFactory

import time

class CommandsManager:
	def __init__(self):
		pass
	
	def processCMD(self, cmd, sock):
		self.commands = ["help", "analytics", "login", "askohd", "askbe"]
		if cmd.startswith("/"):
			gene = 1
		else:
			gene = 0
		
		if cmd[gene:] in self.commands:
			if cmd[gene:] == "help":
				print("All commands: \n /help - get all commands list \n /analytics - send AnalyticsEvent (10110) packet \n /login - send Login (10101) \n /askohd - ask for ohd (14109) \n /askbe - ask battleend (14110)")
			elif cmd[gene:] == "analytics":
				msg = LogicLaserMessageFactory.createMessageByType(self, 10110)
				msg.setA1(input("1 > "))
				msg.setA2(input("2 > "))
				msg.encode()
				Messaging.sendMessage(self, 10110, sock, msg.buff())
			elif cmd[gene:] == "login":
				msg = LogicLaserMessageFactory.createMessageByType(self, 10101)
				token = input("Enter token (leave blank to default) > ")
				if token != "":
					msg.setPassToken(token)
				msg.encode()
				Messaging.sendMessage(self, 10101, sock, msg.buff())
			elif cmd[gene:] == "askohd":
				msg = LogicLaserMessageFactory.createMessageByType(self, 14109)
				msg.encode()
				Messaging.sendMessage(self, 14109, sock, msg.buff())
				Debugger.log("Asked for OHD.")
				
				header = sock.recv(7)
				msgType = int.from_bytes(header[:2], 'big')
				msgLen = int.from_bytes(header[2:5], 'big')
				
				recvedData = b""
				while msgLen > 0:
					dudka = sock.recv(msgLen)
					if not dudka:
						raise EOFError
					recvedData += dudka
					msgLen -= len(dudka)
				
				msgData = recvedData
				
				print(msgType, msgLen)
				
				print("OHD Received: " + str(msgData.hex()))
			
			elif cmd[gene:] == "askbe":
				msg = LogicLaserMessageFactory.createMessageByType(self, 14110)
				brawler = int(input("Brawler (not work) > "))
				howmany = int(input("How many times > "))
				msg.setBrawler(brawler)
				msg.encode()
				for i in range(howmany):
					Messaging.sendMessage(self, 14110, sock, msg.buff())
					print("Asked BattleEnd")
					time.sleep(0.01)
		else:
			pass
	
	def cmd(self, sock):
		cmd = input("> ")
		self.processCMD(cmd, sock)