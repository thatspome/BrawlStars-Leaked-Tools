class PiranhaMessage:
	def __init__(self):
		self.message_type = None
	
	def getMessageType(self):
		return self.message_type
	
	def setMessageType(self, new):
		self.message_type = new