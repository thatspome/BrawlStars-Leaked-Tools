from Streams.ByteStream import ByteStream
from Protocol.PiranhaMessage import PiranhaMessage

class AnalyticsEventMessage(PiranhaMessage):
	def __init__(self):
		self.message_type = 10110
		self.token = ""
		self.ByteStream = ByteStream()
		
		self.a1 = ""
		self.a2 = ""
	
	def setA1(self, new):
		self.a1 = new
	
	def setA2(self, new):
		self.a2 = new
	
	def encode(self):
		self.ByteStream.writeString(self.a1)
		self.ByteStream.writeString(self.a2)
	
	def buff(self):
		return self.ByteStream.buffer