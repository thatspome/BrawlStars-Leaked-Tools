from Streams.ByteStream import ByteStream
from Protocol.PiranhaMessage import PiranhaMessage

class LoginMessage(PiranhaMessage):
	def __init__(self):
		self.message_type = 10101
		self.token = ""
		self.ByteStream = ByteStream()
		
		self.pass_token = "Your Token Here"
	
	def setPassToken(self, new):
		self.pass_token = new
	
	def encode(self):
		self.ByteStream.writeInt(0) # highid
		self.ByteStream.writeInt(1) # lowid
		self.ByteStream.writeString(self.pass_token) # token
		self.ByteStream.writeInt(19) # major
		self.ByteStream.writeInt(0) # build
		self.ByteStream.writeInt(111) # minor
		self.ByteStream.writeString("sha")
		self.ByteStream.writeInt(0)
		self.ByteStream.writeString("2023")
		self.ByteStream.writeString("ahhh")
		self.ByteStream.writeString("tool")
	
	def buff(self):
		return self.ByteStream.buffer