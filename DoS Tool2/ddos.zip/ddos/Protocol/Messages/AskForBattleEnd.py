from Streams.ByteStream import ByteStream
from Protocol.PiranhaMessage import PiranhaMessage

class AskForBattleEnd(PiranhaMessage):
	def __init__(self):
		self.message_type = 14110
		self.ByteStream = ByteStream()
		
		self.brawlerid = 0
	
	def setBrawler(self, new):
		self.brawlerid = new
	
	def encode(self):
		self.ByteStream.writeVInt(2) # result
		self.ByteStream.writeVInt(0)
		self.ByteStream.writeVInt(1) # rank
		self.ByteStream.writeVInt(0)
		self.ByteStream.writeVInt(0)
		self.ByteStream.writeVInt(0)
		self.ByteStream.writeVInt(0)
		self.ByteStream.writeVInt(0)
		self.ByteStream.writeVInt(0)
		self.ByteStream.writeVInt(0)
		
		for i in range(6):
			self.ByteStream.writeVInt(0) # team
			self.ByteStream.writeVInt(0)
			self.ByteStream.writeString("Bot %i" % i) # name
			self.ByteStream.writeVInt(self.brawlerid)
			self.ByteStream.writeVInt(self.brawlerid)
			self.ByteStream.writeVInt(0)
	
	def buff(self):
		return self.ByteStream.buffer