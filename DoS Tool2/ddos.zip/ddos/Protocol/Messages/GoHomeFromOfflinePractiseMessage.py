from Streams.ByteStream import ByteStream
from Protocol.PiranhaMessage import PiranhaMessage

class GoHomeFromOfflinePractiseMessage(PiranhaMessage):
	def __init__(self):
		self.message_type = 14109
		self.ByteStream = ByteStream()
	
	def encode(self):
		pass
	
	def buff(self):
		return self.ByteStream.buffer