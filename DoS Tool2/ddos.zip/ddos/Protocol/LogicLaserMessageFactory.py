from Protocol.Messages.LoginMessage import LoginMessage
from Protocol.Messages.AnalyticsEventMessage import AnalyticsEventMessage
from Protocol.Messages.GoHomeFromOfflinePractiseMessage import GoHomeFromOfflinePractiseMessage
from Protocol.Messages.AskForBattleEnd import AskForBattleEnd

class LogicLaserMessageFactory:
	def createMessageByType(self, type):
		send = False
		message = None
		if type == 10101:
			message = LoginMessage()
		elif type == 10110:
			message = AnalyticsEventMessage()
		elif type == 14109:
			message = GoHomeFromOfflinePractiseMessage()
		elif type == 14110:
			message = AskForBattleEnd()
		return message