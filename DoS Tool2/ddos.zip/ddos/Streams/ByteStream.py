import zlib

class ByteStream:
	def __init__(self):
		self.buffer = b""
		self.offset = 0
	
	def getBuff(self):
		return self.buffer
	
	def cleanBuff(self):
		self.buffer = b""
	
	def setBuff(self, new):
		self.buffer = new
	
	def getOffset(self):
		return self.offset
	
	def cleanOffset(self):
		self.setOffset(0)
	
	def setOffset(self, new):
		self.offset = new
	
	
	def writeInt(self, value, length = 4):
		self.buffer += value.to_bytes(length, 'big', signed = value < 0)
	
	def writeString(self, string: str = None):
		if string == None or string == "":
			val = -1
		else:
			val = len(string)
		ByteStream.writeInt(self, val)
		self.buffer += string.encode("utf-8")
	
	def writeCompressedString(self, text):
		text = zlib.compress(text)
		ByteStream.writeInt(self, len(text) + 4)
		ByteStream.writeIntLittleEndian(self, len(text))
		self.buffer += text
	
	def writeByte(self, value):
		ByteStream.writeInt(self, value, 1)
	
	def writeBoolean(self, boolean):
		if boolean:
			val = 1
		else:
			val = 0
		ByteStream.writeByte(self, val)
	
	def writeVInt(self, data, rotate: bool = True):
		final = b''
		if data == 0:
			self.writeByte(0)
		else:
			data = (data << 1) ^ (data >> 31)
			while data:
				b = data & 0x7f

				if data >= 0x80:
					b |= 0x80
				if rotate:
					rotate = False
					lsb = b & 0x1
					msb = (b & 0x80) >> 7
					b >>= 1
					b = b & ~0xC0
					b = b | (msb << 7) | (lsb << 6)

				final += b.to_bytes(1, 'big')
				data >>= 7
		self.buffer += final
	
	def writeDataReference(self, a1, a2):
		ByteStream.writeVInt(self, a1)
		ByteStream.writeVInt(self, a2)
	
	def writeLong(self, a1, a2):
		ByteStream.writeInt(self, a1)
		ByteStream.writeInt(self, a2)
	
	def writeIntLittleEndian(self, value):
		tempBuf = list(self.buffer)
		tempBuf.append(value & 0xFF)
		tempBuf.append(value >> 8 & 0xFF)
		tempBuf.append(value >> 16 & 0xFF)
		tempBuf.append(value >> 24 & 0xFF)
		self.buffer = bytes(tempBuf)