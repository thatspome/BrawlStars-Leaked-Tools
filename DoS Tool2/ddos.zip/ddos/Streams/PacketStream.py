import struct

class PacketStream:
	def __init__(self):
		pass
	
	def writeShort(value):
		return struct.pack('>H', value)